# Lead Manager PWA - Icon Placeholder

The app icons need to be added manually. Please create or use the following:

## Required Icons:
- `public/icons/icon-192.png` - 192x192 pixels
- `public/icons/icon-512.png` - 512x512 pixels

## Icon Design Suggestions:
- Use a gradient background from indigo (#4F46E5) to purple
- Include a simple white icon representing leads/contacts (person silhouette, checkmark, etc.)
- Keep it minimal and professional
- Ensure it works well at small sizes

## Quick Option:
You can use a free icon generator like:
- https://favicon.io/
- https://realfavicongenerator.net/
- Or create custom icons in Figma/Canva

For now, the app will work without icons, but they're recommended for the best PWA experience.
