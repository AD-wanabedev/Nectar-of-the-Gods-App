# Quick Start Guide - Lead Manager PWA

## ⚠️ Important: Node.js Version Issue

Your current Node.js version (12.22.12) is too old to run the development server. You need to upgrade to Node.js 18+ or 20+.

### Option 1: Upgrade Node.js (Recommended)

```bash
# Using nvm (if installed)
nvm install 20
nvm use 20

# Or download from https://nodejs.org/ (LTS version)
```

After upgrading Node, run:
```bash
cd "/Users/sharjeelshaikh/Downloads/Nectar of the Gods/lead-manager-pwa"
npm install
npm run dev
```

### Option 2: Test Without Dev Server

If you can't upgrade Node right now, you can still test the app by:

1. **Deploy to a hosting service** that builds for you:
   - **Netlify**: Drag and drop the project folder
   - **Vercel**: Connect GitHub repo
   - **Firebase Hosting**: Use Firebase CLI

2. **Use a simple HTTP server** (won't have hot reload):
   ```bash
   # Install http-server globally
   npm install -g http-server
   
   # Serve the project
   cd "/Users/sharjeelshaikh/Downloads/Nectar of the Gods/lead-manager-pwa"
   http-server -p 8080
   ```
   Then open `http://localhost:8080` in your browser.

---

## After Node Upgrade - First Run

```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev

# 3. Open browser to http://localhost:5173
```

---

## Adding App Icons

Create two PNG files:
- `public/icons/icon-192.png` (192x192 pixels)
- `public/icons/icon-512.png` (512x512 pixels)

**Quick icon generator**: https://favicon.io/

---

## Firebase Setup (Optional - for cloud sync)

1. Go to https://console.firebase.google.com/
2. Create a new project
3. Add a Web app
4. Copy the Firebase configuration
5. Update `src/config/firebase.js`:

```javascript
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

---

## Testing on Android

1. **Build for production**:
   ```bash
   npm run build
   ```

2. **Deploy to HTTPS hosting** (required for PWA):
   - Firebase Hosting
   - Netlify
   - Vercel
   - GitHub Pages

3. **Open on Android device**:
   - Visit the deployed URL
   - Tap "Add to Home Screen"
   - Test offline mode

---

## Features to Test

- [ ] Create a lead in under 10 seconds
- [ ] Add a reminder with notification
- [ ] Use voice-to-text for notes
- [ ] Share collateral via WhatsApp
- [ ] Test offline mode (airplane mode)
- [ ] Verify data persists after closing app

---

## Troubleshooting

### "Module not found" errors
```bash
rm -rf node_modules package-lock.json
npm install
```

### PWA not installing
- Must be served over HTTPS (or localhost)
- Check browser console for errors
- Ensure icons exist in `public/icons/`

### Voice input not working
- Only works on HTTPS or localhost
- Only supported in Chrome/Edge/Android
- Check microphone permissions

---

## Next Steps

1. ✅ Upgrade Node.js to 18+ or 20+
2. ✅ Run `npm install && npm run dev`
3. ✅ Add app icons to `public/icons/`
4. ⏳ Test all features locally
5. ⏳ Deploy to HTTPS hosting
6. ⏳ Test on Android device
7. ⏳ (Optional) Set up Firebase for cloud sync

---

## Support

- **README**: See [README.md](file:///Users/sharjeelshaikh/Downloads/Nectar%20of%20the%20Gods/lead-manager-pwa/README.md) for detailed documentation
- **Walkthrough**: See walkthrough.md in artifacts for implementation details
- **Code**: All source code is in `src/` directory with comments
