# Lead Manager PWA

A lightweight, offline-first Progressive Web App for personal lead management with follow-up reminders and collateral library, optimized for Android/Nothing OS.

## Features

- **Offline-First**: Works completely offline with automatic sync when online
- **Lead Management**: Capture and manage leads with priority, source tracking, and notes
- **Smart Reminders**: Set follow-up reminders with push notifications
- **Collateral Library**: Organize and share PDFs, images, videos, and templates
- **WhatsApp Integration**: Quick sharing via WhatsApp
- **Voice-to-Text**: Add notes using voice input (Chrome/Android)
- **Mobile-Optimized**: Fast, thumb-friendly UI designed for mobile

## Getting Started

### Prerequisites

- Node.js 14+ (recommended) or Node.js 12+ (with limitations)
- npm 6+

### Installation

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

### Firebase Setup (Optional)

To enable cloud sync and authentication:

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project or select existing
3. Go to Project Settings > General
4. Add a Web app and copy the configuration
5. Update `src/config/firebase.js` with your Firebase config

### App Icons

Add your app icons to `public/icons/`:
- `icon-192.png` (192x192 pixels)
- `icon-512.png` (512x512 pixels)

See `public/icons/README.md` for design guidelines.

## Usage

### Adding a Lead

1. Tap the + button on the Leads screen
2. Fill in name (required), phone, email, source, and priority
3. Optionally set next follow-up date and add notes
4. Tap "Save Lead"

### Setting Reminders

1. From a lead card, tap "⏰ Reminder"
2. Choose reminder type (Call, WhatsApp, Send Collateral, Meeting)
3. Set date and time
4. Tap "Set Reminder"

### Today Screen

- View all due and overdue follow-ups
- Sorted by priority (High → Medium → Low)
- Quick actions: Call, WhatsApp, Mark Done, Snooze

### Collateral Library

- Organize files into folders (Retail, B2B, Distributor, Custom)
- Share directly with leads via WhatsApp or other apps
- Support for PDFs, images, videos, Drive links, and text templates

## Technical Stack

- **Frontend**: Vite + Vanilla JavaScript
- **Database**: IndexedDB (via Dexie.js)
- **PWA**: Vite PWA Plugin + Workbox
- **Backend** (Optional): Firebase (Auth + Firestore)
- **Styling**: Modern CSS with CSS Variables

## Browser Support

- Chrome/Edge 90+
- Safari 14+
- Firefox 88+
- Android WebView 90+

## License

MIT

## Support

For issues or questions, please open an issue on GitHub.
