// Share content via Web Share API
export async function shareContent(data) {
    if (navigator.share) {
        try {
            await navigator.share(data);
            return true;
        } catch (err) {
            if (err.name !== 'AbortError') {
                console.error('Error sharing:', err);
            }
            return false;
        }
    }
    return false;
}

// Share collateral with lead via WhatsApp
export function shareViaWhatsApp(phone, message, url = null) {
    let text = message;
    if (url) {
        text += `\n\n${url}`;
    }

    // Remove any non-numeric characters from phone
    const cleanPhone = phone.replace(/\D/g, '');

    // WhatsApp URL scheme
    const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;

    window.open(whatsappUrl, '_blank');
}

// Open Gmail for lead
export function openGmail(email, subject = '', body = '') {
    const gmailUrl = `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = gmailUrl;
}

// Share collateral
export async function shareCollateral(collateral, lead = null) {
    const shareData = {
        title: collateral.name,
        text: `Check out this: ${collateral.name}`,
    };

    if (collateral.url) {
        shareData.url = collateral.url;
    }

    // Try Web Share API first
    const shared = await shareContent(shareData);

    // If Web Share not available and lead has phone, offer WhatsApp
    if (!shared && lead && lead.phone) {
        const useWhatsApp = confirm('Share via WhatsApp?');
        if (useWhatsApp) {
            shareViaWhatsApp(lead.phone, shareData.text, collateral.url);
        }
    }
}
