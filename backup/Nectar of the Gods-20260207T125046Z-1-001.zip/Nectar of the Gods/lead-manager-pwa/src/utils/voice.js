// Initialize Web Speech API
let recognition = null;

if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;
}

// Check if voice input is supported
export function isVoiceSupported() {
    return recognition !== null;
}

// Start voice recognition
export function startVoiceRecognition(onResult, onError) {
    if (!recognition) {
        onError && onError(new Error('Speech recognition not supported'));
        return;
    }

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        onResult && onResult(transcript);
    };

    recognition.onerror = (event) => {
        onError && onError(event.error);
    };

    recognition.start();
}

// Stop voice recognition
export function stopVoiceRecognition() {
    if (recognition) {
        recognition.stop();
    }
}
