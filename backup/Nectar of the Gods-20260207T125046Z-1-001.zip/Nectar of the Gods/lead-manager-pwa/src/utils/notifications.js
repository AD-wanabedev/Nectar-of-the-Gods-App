// Request notification permission
export async function requestNotificationPermission() {
    if (!('Notification' in window)) {
        console.warn('This browser does not support notifications');
        return false;
    }

    if (Notification.permission === 'granted') {
        return true;
    }

    if (Notification.permission !== 'denied') {
        const permission = await Notification.requestPermission();
        return permission === 'granted';
    }

    return false;
}

// Show notification with service worker support
export async function showNotification(title, options = {}) {
    if (Notification.permission !== 'granted') {
        return null;
    }

    const defaultOptions = {
        icon: '/icons/icon-192.png',
        badge: '/icons/icon-192.png',
        vibrate: [200, 100, 200],
        requireInteraction: true,
        ...options
    };

    // Try to use service worker for better notification support
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
        try {
            const registration = await navigator.serviceWorker.ready;
            await registration.showNotification(title, defaultOptions);
            return true;
        } catch (error) {
            console.error('Service worker notification failed:', error);
        }
    }

    // Fallback to regular notification
    const notification = new Notification(title, defaultOptions);
    return notification;
}

// Schedule reminder notification
export function scheduleReminderNotification(reminder, lead) {
    const dueTime = new Date(reminder.dueDateTime).getTime();
    const now = Date.now();
    const delay = dueTime - now;

    if (delay > 0 && delay < 2147483647) { // Max setTimeout delay
        const timeoutId = setTimeout(() => {
            showNotification(`Follow-up Due: ${lead.name}`, {
                body: `${reminder.type} - ${lead.name}`,
                tag: `reminder-${reminder.id}`,
                data: {
                    reminderId: reminder.id,
                    leadId: lead.id,
                    action: 'reminder-due'
                },
                actions: [
                    { action: 'mark-done', title: '✓ Mark Done', icon: '/icons/icon-192.png' },
                    { action: 'snooze', title: '⏰ Snooze 1hr', icon: '/icons/icon-192.png' },
                    { action: 'view', title: '👁 View Lead', icon: '/icons/icon-192.png' }
                ]
            });
        }, delay);

        // Store timeout ID for potential cancellation
        return timeoutId;
    } else if (delay <= 0) {
        // Reminder is overdue, show immediately
        showNotification(`Overdue: ${lead.name}`, {
            body: `${reminder.type} - ${lead.name}`,
            tag: `reminder-${reminder.id}`,
            data: {
                reminderId: reminder.id,
                leadId: lead.id,
                action: 'reminder-overdue'
            }
        });
    }

    return null;
}

// Cancel scheduled notification
export function cancelScheduledNotification(timeoutId) {
    if (timeoutId) {
        clearTimeout(timeoutId);
    }
}

// Check for due reminders and schedule notifications
export async function checkAndScheduleReminders(reminders, leads) {
    const scheduledIds = [];

    for (const reminder of reminders) {
        if (reminder.status === 'pending') {
            const lead = leads.find(l => l.id === reminder.leadId);
            if (lead) {
                const timeoutId = scheduleReminderNotification(reminder, lead);
                if (timeoutId) {
                    scheduledIds.push({ reminderId: reminder.id, timeoutId });
                }
            }
        }
    }

    return scheduledIds;
}

// Show notification for new lead
export function notifyNewLead(lead) {
    showNotification('New Lead Added', {
        body: `${lead.name} - ${lead.leadType || 'Retail'}`,
        tag: `lead-${lead.id}`,
        data: { leadId: lead.id, action: 'new-lead' }
    });
}

// Show notification for upcoming follow-up (15 min before)
export function scheduleFollowUpReminder(lead) {
    if (!lead.nextFollowUp) return null;

    const followUpTime = new Date(lead.nextFollowUp).getTime();
    const now = Date.now();
    const fifteenMinutes = 15 * 60 * 1000;
    const delay = followUpTime - now - fifteenMinutes;

    if (delay > 0 && delay < 2147483647) {
        const timeoutId = setTimeout(() => {
            showNotification('Follow-up in 15 minutes', {
                body: `${lead.name} - ${lead.priority} priority`,
                tag: `followup-${lead.id}`,
                data: { leadId: lead.id, action: 'followup-soon' }
            });
        }, delay);

        return timeoutId;
    }

    return null;
}
