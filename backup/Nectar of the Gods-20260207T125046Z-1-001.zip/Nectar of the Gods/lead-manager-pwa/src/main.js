import './db/schema.js';
import { renderTodayScreen } from './screens/today.js';
import { renderLeadsScreen, resetFilters } from './screens/leads.js';
import { renderLibraryScreen } from './screens/library.js';
import { createLead, updateLead, getLeadById } from './db/leads.js';
import { createReminder } from './db/reminders.js';
import { requestNotificationPermission } from './utils/notifications.js';
import { isVoiceSupported, startVoiceRecognition } from './utils/voice.js';

// App state
const app = {
    currentScreen: 'today',
    editingLeadId: null
};

// Initialize app
async function init() {
    console.log('Initializing Lead Manager PWA...');

    // Request notification permission
    await requestNotificationPermission();

    // Set up navigation
    setupNavigation();

    // Set up modals
    setupLeadModal();
    setupReminderModal();

    // Set up FAB
    setupFAB();

    // Load initial screen
    await navigateToScreen('today');

    // Hide loading, show content
    document.getElementById('loading').style.display = 'none';
    document.getElementById('main-content').classList.remove('hidden');

    console.log('App initialized!');
}

// Navigation
function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');

    navItems.forEach(item => {
        item.addEventListener('click', async (e) => {
            e.preventDefault();
            const screen = e.currentTarget.dataset.screen;
            await navigateToScreen(screen);
        });
    });
}

async function navigateToScreen(screenName) {
    app.currentScreen = screenName;

    // Update nav active state
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.screen === screenName);
    });

    // Hide all screens
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.add('hidden');
    });

    // Show current screen
    const currentScreenEl = document.getElementById(`${screenName}-screen`);
    currentScreenEl.classList.remove('hidden');

    // Render screen content
    switch (screenName) {
        case 'today':
            await renderTodayScreen();
            document.getElementById('fab').classList.add('hidden');
            break;
        case 'leads':
            await renderLeadsScreen();
            document.getElementById('fab').classList.remove('hidden');
            break;
        case 'library':
            await renderLibraryScreen();
            document.getElementById('fab').classList.add('hidden');
            break;
    }
}

// FAB
function setupFAB() {
    const fab = document.getElementById('fab');
    fab.addEventListener('click', () => {
        openLeadModal();
    });
}

// Lead Modal
function setupLeadModal() {
    const modal = document.getElementById('lead-modal');
    const form = document.getElementById('lead-form');
    const closeBtn = modal.querySelector('.modal-close');
    const cancelBtn = document.getElementById('cancel-btn');
    const sourceSelect = document.getElementById('lead-source');
    const emailInput = document.getElementById('lead-email');
    const emailRequired = document.getElementById('email-required');
    const voiceBtn = document.getElementById('voice-btn');
    const notesInput = document.getElementById('lead-notes');

    // Priority chips
    const priorityChips = document.querySelectorAll('.priority-chip');
    priorityChips.forEach(chip => {
        chip.addEventListener('click', (e) => {
            e.preventDefault();
            priorityChips.forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            document.getElementById('lead-priority').value = chip.dataset.priority;
        });
    });

    // Source change - Gmail logic
    sourceSelect.addEventListener('change', (e) => {
        if (e.target.value === 'Gmail') {
            emailInput.required = true;
            emailRequired.classList.remove('hidden');
        } else {
            emailInput.required = false;
            emailRequired.classList.add('hidden');
        }
    });

    // Voice input
    if (isVoiceSupported()) {
        voiceBtn.addEventListener('click', (e) => {
            e.preventDefault();
            voiceBtn.textContent = '🎙️';

            startVoiceRecognition(
                (transcript) => {
                    notesInput.value += (notesInput.value ? ' ' : '') + transcript;
                    voiceBtn.textContent = '🎤';
                },
                (error) => {
                    console.error('Voice recognition error:', error);
                    voiceBtn.textContent = '🎤';
                    alert('Voice input failed. Please try again.');
                }
            );
        });
    } else {
        voiceBtn.style.display = 'none';
    }

    // Close modal
    const closeModal = () => {
        modal.classList.remove('active');
        form.reset();
        app.editingLeadId = null;
        document.getElementById('modal-title').textContent = 'New Lead';
        priorityChips.forEach(c => c.classList.remove('active'));
        priorityChips[1].classList.add('active'); // Default to Medium
    };

    closeBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    // Form submit
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const leadData = {
            name: formData.get('name'),
            phone: formData.get('phone'),
            email: formData.get('email'),
            source: formData.get('source'),
            priority: formData.get('priority'),
            nextFollowUp: formData.get('nextFollowUp') || null,
            notes: formData.get('notes')
        };

        try {
            if (app.editingLeadId) {
                await updateLead(app.editingLeadId, leadData);
            } else {
                await createLead(leadData);
            }

            closeModal();

            // Refresh current screen
            await navigateToScreen(app.currentScreen);
        } catch (error) {
            console.error('Error saving lead:', error);
            alert('Failed to save lead. Please try again.');
        }
    });
}

async function openLeadModal(leadId = null) {
    const modal = document.getElementById('lead-modal');
    const form = document.getElementById('lead-form');

    if (leadId) {
        // Edit mode
        app.editingLeadId = leadId;
        const lead = await getLeadById(leadId);

        document.getElementById('modal-title').textContent = 'Edit Lead';
        document.getElementById('lead-id').value = lead.id;
        document.getElementById('lead-name').value = lead.name;
        document.getElementById('lead-phone').value = lead.phone || '';
        document.getElementById('lead-email').value = lead.email || '';
        document.getElementById('lead-source').value = lead.source;
        document.getElementById('lead-priority').value = lead.priority;
        document.getElementById('lead-followup').value = lead.nextFollowUp || '';
        document.getElementById('lead-notes').value = lead.notes || '';

        // Update priority chips
        document.querySelectorAll('.priority-chip').forEach(chip => {
            chip.classList.toggle('active', chip.dataset.priority === lead.priority);
        });

        // Trigger source change for Gmail logic
        if (lead.source === 'Gmail') {
            document.getElementById('lead-email').required = true;
            document.getElementById('email-required').classList.remove('hidden');
        }
    } else {
        // New lead mode
        form.reset();
        document.getElementById('modal-title').textContent = 'New Lead';
        document.querySelectorAll('.priority-chip').forEach((chip, i) => {
            chip.classList.toggle('active', i === 1); // Default to Medium
        });
    }

    modal.classList.add('active');

    // Focus name input
    setTimeout(() => {
        document.getElementById('lead-name').focus();
    }, 300);
}

// Reminder Modal
function setupReminderModal() {
    const modal = document.getElementById('reminder-modal');
    const form = document.getElementById('reminder-form');
    const closeBtn = modal.querySelector('.modal-close');
    const cancelBtn = document.getElementById('cancel-reminder-btn');

    const closeModal = () => {
        modal.classList.remove('active');
        form.reset();
    };

    closeBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const reminderData = {
            leadId: parseInt(formData.get('leadId')),
            type: formData.get('type'),
            dueDateTime: formData.get('dueDateTime')
        };

        try {
            await createReminder(reminderData);
            closeModal();

            // Refresh current screen
            await navigateToScreen(app.currentScreen);
        } catch (error) {
            console.error('Error creating reminder:', error);
            alert('Failed to create reminder. Please try again.');
        }
    });
}

function openReminderModal(leadId) {
    const modal = document.getElementById('reminder-modal');
    document.getElementById('reminder-lead-id').value = leadId;

    // Set default datetime to 1 hour from now
    const now = new Date();
    now.setHours(now.getHours() + 1);
    const datetimeStr = now.toISOString().slice(0, 16);
    document.getElementById('reminder-datetime').value = datetimeStr;

    modal.classList.add('active');
}

// Expose app methods globally for screen components
window.app = {
    ...app,
    navigateToScreen,
    openLeadModal,
    openReminderModal
};

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
