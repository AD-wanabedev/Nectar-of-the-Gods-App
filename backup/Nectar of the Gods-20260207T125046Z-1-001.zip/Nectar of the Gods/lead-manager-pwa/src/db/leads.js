import db from './schema.js';

// Create a new lead
export async function createLead(leadData) {
    const now = new Date().toISOString();
    const lead = {
        ...leadData,
        createdAt: now,
        updatedAt: now,
        syncStatus: 'pending'
    };

    const id = await db.leads.add(lead);

    // Add to sync queue
    await db.syncQueue.add({
        collection: 'leads',
        operation: 'create',
        data: { ...lead, id },
        timestamp: now
    });

    return { ...lead, id };
}

// Get all leads
export async function getAllLeads() {
    return await db.leads.toArray();
}

// Get lead by ID
export async function getLeadById(id) {
    return await db.leads.get(id);
}

// Update lead
export async function updateLead(id, updates) {
    const now = new Date().toISOString();
    await db.leads.update(id, {
        ...updates,
        updatedAt: now,
        syncStatus: 'pending'
    });

    // Add to sync queue
    await db.syncQueue.add({
        collection: 'leads',
        operation: 'update',
        data: { id, ...updates },
        timestamp: now
    });

    return await getLeadById(id);
}

// Delete lead
export async function deleteLead(id) {
    await db.leads.delete(id);

    // Delete associated reminders
    await db.reminders.where('leadId').equals(id).delete();

    // Add to sync queue
    await db.syncQueue.add({
        collection: 'leads',
        operation: 'delete',
        data: { id },
        timestamp: new Date().toISOString()
    });
}

// Search leads
export async function searchLeads(query) {
    const lowerQuery = query.toLowerCase();
    return await db.leads
        .filter(lead =>
            lead.name.toLowerCase().includes(lowerQuery) ||
            (lead.phone && lead.phone.includes(query)) ||
            (lead.email && lead.email.toLowerCase().includes(lowerQuery))
        )
        .toArray();
}

// Filter leads by source
export async function filterLeadsBySource(source) {
    return await db.leads.where('source').equals(source).toArray();
}

// Filter leads by priority
export async function filterLeadsByPriority(priority) {
    return await db.leads.where('priority').equals(priority).toArray();
}

// Get leads with filters
export async function getLeadsWithFilters({ search, leadType, priority }) {
    let leads = await getAllLeads();

    if (search) {
        const lowerQuery = search.toLowerCase();
        leads = leads.filter(lead =>
            lead.name.toLowerCase().includes(lowerQuery) ||
            (lead.phone && lead.phone.includes(search)) ||
            (lead.email && lead.email.toLowerCase().includes(lowerQuery))
        );
    }

    if (leadType) {
        leads = leads.filter(lead => lead.leadType === leadType);
    }

    if (priority) {
        leads = leads.filter(lead => lead.priority === priority);
    }

    return leads;
}
