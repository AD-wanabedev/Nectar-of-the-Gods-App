import db from './schema.js';

// Create collateral
export async function createCollateral(collateralData) {
    const now = new Date().toISOString();
    const collateral = {
        ...collateralData,
        createdAt: now,
        syncStatus: 'pending'
    };

    const id = await db.collateral.add(collateral);

    // Add to sync queue
    await db.syncQueue.add({
        collection: 'collateral',
        operation: 'create',
        data: { ...collateral, id },
        timestamp: now
    });

    return { ...collateral, id };
}

// Get all collateral
export async function getAllCollateral() {
    return await db.collateral.toArray();
}

// Get collateral by folder
export async function getCollateralByFolder(folder) {
    return await db.collateral.where('folder').equals(folder).toArray();
}

// Get collateral by ID
export async function getCollateralById(id) {
    return await db.collateral.get(id);
}

// Update collateral
export async function updateCollateral(id, updates) {
    await db.collateral.update(id, {
        ...updates,
        syncStatus: 'pending'
    });

    // Add to sync queue
    await db.syncQueue.add({
        collection: 'collateral',
        operation: 'update',
        data: { id, ...updates },
        timestamp: new Date().toISOString()
    });

    return await getCollateralById(id);
}

// Delete collateral
export async function deleteCollateral(id) {
    await db.collateral.delete(id);

    // Add to sync queue
    await db.syncQueue.add({
        collection: 'collateral',
        operation: 'delete',
        data: { id },
        timestamp: new Date().toISOString()
    });
}
