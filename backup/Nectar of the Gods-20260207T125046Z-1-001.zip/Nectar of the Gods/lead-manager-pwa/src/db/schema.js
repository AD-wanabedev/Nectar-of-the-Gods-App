import Dexie from 'dexie';

// Initialize Dexie database
export const db = new Dexie('LeadManagerDB');

// Define schema
db.version(1).stores({
    leads: '++id, name, phone, email, source, leadType, priority, nextFollowUp, createdAt, updatedAt, syncStatus',
    reminders: '++id, leadId, type, dueDateTime, status, createdAt, syncStatus',
    collateral: '++id, folder, name, type, url, createdAt, syncStatus',
    syncQueue: '++id, collection, operation, data, timestamp'
});

// Open database
db.open().catch(err => {
    console.error('Failed to open database:', err);
});

export default db;
