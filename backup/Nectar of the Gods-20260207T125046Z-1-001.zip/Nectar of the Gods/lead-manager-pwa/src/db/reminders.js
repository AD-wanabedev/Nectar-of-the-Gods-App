import db from './schema.js';

// Create a new reminder
export async function createReminder(reminderData) {
    const now = new Date().toISOString();
    const reminder = {
        ...reminderData,
        status: 'pending',
        createdAt: now,
        syncStatus: 'pending'
    };

    const id = await db.reminders.add(reminder);

    // Add to sync queue
    await db.syncQueue.add({
        collection: 'reminders',
        operation: 'create',
        data: { ...reminder, id },
        timestamp: now
    });

    // Schedule notification
    scheduleNotification({ ...reminder, id });

    return { ...reminder, id };
}

// Get all reminders
export async function getAllReminders() {
    return await db.reminders.toArray();
}

// Get reminder by ID
export async function getReminderById(id) {
    return await db.reminders.get(id);
}

// Get reminders for a lead
export async function getRemindersByLeadId(leadId) {
    return await db.reminders.where('leadId').equals(leadId).toArray();
}

// Get due and overdue reminders
export async function getDueReminders() {
    const now = new Date().toISOString();
    return await db.reminders
        .where('dueDateTime')
        .belowOrEqual(now)
        .and(r => r.status === 'pending')
        .toArray();
}

// Get today's reminders
export async function getTodayReminders() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    return await db.reminders
        .where('dueDateTime')
        .between(today.toISOString(), tomorrow.toISOString(), true, false)
        .and(r => r.status === 'pending')
        .toArray();
}

// Update reminder
export async function updateReminder(id, updates) {
    await db.reminders.update(id, {
        ...updates,
        syncStatus: 'pending'
    });

    // Add to sync queue
    await db.syncQueue.add({
        collection: 'reminders',
        operation: 'update',
        data: { id, ...updates },
        timestamp: new Date().toISOString()
    });

    return await getReminderById(id);
}

// Mark reminder as done
export async function markReminderDone(id) {
    return await updateReminder(id, { status: 'done' });
}

// Snooze reminder
export async function snoozeReminder(id, minutes = 60) {
    const newDateTime = new Date();
    newDateTime.setMinutes(newDateTime.getMinutes() + minutes);

    return await updateReminder(id, {
        status: 'snoozed',
        snoozedUntil: newDateTime.toISOString(),
        dueDateTime: newDateTime.toISOString()
    });
}

// Delete reminder
export async function deleteReminder(id) {
    await db.reminders.delete(id);

    // Add to sync queue
    await db.syncQueue.add({
        collection: 'reminders',
        operation: 'delete',
        data: { id },
        timestamp: new Date().toISOString()
    });
}

// Schedule notification (placeholder - will be implemented in notifications.js)
function scheduleNotification(reminder) {
    // This will be implemented with service worker
    console.log('Scheduling notification for reminder:', reminder.id);
}
