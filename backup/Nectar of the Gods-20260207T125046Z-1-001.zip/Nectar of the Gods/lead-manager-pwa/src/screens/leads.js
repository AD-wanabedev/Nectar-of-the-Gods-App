import { getAllLeads, getLeadsWithFilters, deleteLead } from '../db/leads.js';
import { formatDate } from '../utils/date.js';

let currentFilters = {
  search: '',
  leadType: null,
  priority: null
};

export async function renderLeadsScreen() {
  const container = document.getElementById('leads-screen');

  // Get leads with current filters
  const leads = await getLeadsWithFilters(currentFilters);

  // Sort by updated date (most recent first)
  leads.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));

  container.innerHTML = `
    <div class="screen-header">
      <h1 class="screen-title">Leads</h1>
      <p class="text-secondary">${leads.length} lead${leads.length !== 1 ? 's' : ''}</p>
    </div>
    
    <div class="search-bar">
      <span class="search-icon">🔍</span>
      <input 
        type="search" 
        class="search-input" 
        placeholder="Search leads..." 
        value="${currentFilters.search}"
        id="lead-search"
      >
    </div>
    
    <div class="filter-chips">
      <button class="chip ${!currentFilters.leadType && !currentFilters.priority ? 'active' : ''}" data-filter="all">All</button>
      <button class="chip ${currentFilters.leadType === 'Retail' ? 'active' : ''}" data-filter="leadType" data-value="Retail">Retail</button>
      <button class="chip ${currentFilters.leadType === 'B2B' ? 'active' : ''}" data-filter="leadType" data-value="B2B">B2B</button>
      <button class="chip ${currentFilters.leadType === 'Distributor' ? 'active' : ''}" data-filter="leadType" data-value="Distributor">Distributor</button>
      <button class="chip ${currentFilters.leadType === 'Custom' ? 'active' : ''}" data-filter="leadType" data-value="Custom">Custom</button>
      <button class="chip ${currentFilters.priority === 'High' ? 'active' : ''}" data-filter="priority" data-value="High">High Priority</button>
      <button class="chip ${currentFilters.priority === 'Medium' ? 'active' : ''}" data-filter="priority" data-value="Medium">Medium</button>
      <button class="chip ${currentFilters.priority === 'Low' ? 'active' : ''}" data-filter="priority" data-value="Low">Low</button>
    </div>
    
    ${leads.length === 0 ? renderEmptyState() : ''}
    
    <div class="leads-list">
      ${leads.map(renderLeadCard).join('')}
    </div>
  `;

  // Show FAB on leads screen
  document.getElementById('fab').classList.remove('hidden');

  // Attach event listeners
  attachLeadEventListeners();
}

function renderEmptyState() {
  return `
    <div class="empty-state">
      <div class="empty-icon">👥</div>
      <h3 class="empty-title">No leads yet</h3>
      <p class="empty-text">Tap the + button to add your first lead</p>
    </div>
  `;
}

function renderLeadCard(lead) {
  return `
    <div class="card mb-md" data-lead-id="${lead.id}">
      <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: var(--spacing-sm);">
        <div>
          <h3 style="font-size: var(--font-size-lg); margin-bottom: var(--spacing-xs);">${lead.name}</h3>
          <div style="display: flex; gap: var(--spacing-sm); align-items: center; flex-wrap: wrap;">
            <span class="priority-badge priority-${lead.priority.toLowerCase()}">${lead.priority}</span>
            ${lead.leadType ? `<span style="font-size: var(--font-size-xs); padding: 2px 8px; background: var(--glass-bg); border: 1px solid var(--glass-border); border-radius: var(--radius-full); color: var(--color-accent);">${lead.leadType}</span>` : ''}
            <span style="font-size: var(--font-size-xs); color: var(--color-text-tertiary);">${lead.source}</span>
          </div>
        </div>
        <button class="btn-icon btn-secondary btn-menu" aria-label="More options">⋮</button>
      </div>
      
      <div style="margin-bottom: var(--spacing-md); font-size: var(--font-size-sm); color: var(--color-text-secondary);">
        ${lead.phone ? `<div style="margin-bottom: var(--spacing-xs);">📞 ${lead.phone}</div>` : ''}
        ${lead.email ? `<div style="margin-bottom: var(--spacing-xs);">✉️ ${lead.email}</div>` : ''}
        ${lead.nextFollowUp ? `<div style="margin-bottom: var(--spacing-xs);">📅 Next: ${formatDate(lead.nextFollowUp)}</div>` : ''}
        ${lead.notes ? `<div style="margin-top: var(--spacing-sm); font-style: italic;">"${lead.notes.substring(0, 100)}${lead.notes.length > 100 ? '...' : ''}"</div>` : ''}
      </div>
      
      <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: var(--spacing-sm);">
        <button class="btn btn-secondary btn-edit" style="font-size: var(--font-size-sm);">✏️ Edit</button>
        <button class="btn btn-secondary btn-add-reminder" style="font-size: var(--font-size-sm);">⏰ Reminder</button>
      </div>
    </div>
  `;
}

function attachLeadEventListeners() {
  // Search input
  const searchInput = document.getElementById('lead-search');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      currentFilters.search = e.target.value;
      debounce(() => renderLeadsScreen(), 300)();
    });
  }

  // Filter chips
  document.querySelectorAll('.filter-chips .chip').forEach(chip => {
    chip.addEventListener('click', (e) => {
      const filterType = e.target.dataset.filter;
      const filterValue = e.target.dataset.value;

      if (filterType === 'all') {
        currentFilters.source = null;
        currentFilters.priority = null;
      } else if (filterType === 'source') {
        currentFilters.source = currentFilters.source === filterValue ? null : filterValue;
        currentFilters.priority = null;
      } else if (filterType === 'priority') {
        currentFilters.priority = currentFilters.priority === filterValue ? null : filterValue;
        currentFilters.source = null;
      }

      renderLeadsScreen();
    });
  });

  // Edit buttons
  document.querySelectorAll('.btn-edit').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const card = e.target.closest('.card');
      const leadId = parseInt(card.dataset.leadId);
      window.app.openLeadModal(leadId);
    });
  });

  // Add reminder buttons
  document.querySelectorAll('.btn-add-reminder').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const card = e.target.closest('.card');
      const leadId = parseInt(card.dataset.leadId);
      window.app.openReminderModal(leadId);
    });
  });

  // Menu buttons (for delete)
  document.querySelectorAll('.btn-menu').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const card = e.target.closest('.card');
      const leadId = parseInt(card.dataset.leadId);

      if (confirm('Delete this lead?')) {
        await deleteLead(leadId);
        renderLeadsScreen();
      }
    });
  });
}

// Debounce helper
let debounceTimer;
function debounce(func, delay) {
  return function () {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(func, delay);
  };
}

// Reset filters when leaving screen
export function resetFilters() {
  currentFilters = {
    search: '',
    source: null,
    priority: null
  };
}
