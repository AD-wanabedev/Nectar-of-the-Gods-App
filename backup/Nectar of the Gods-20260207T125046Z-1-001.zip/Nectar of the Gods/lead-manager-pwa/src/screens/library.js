import { getAllCollateral, getCollateralByFolder, createCollateral, deleteCollateral } from '../db/collateral.js';
import { shareCollateral } from '../utils/share.js';

const FOLDERS = ['Retail', 'B2B', 'Distributor', 'Custom'];
let currentFolder = 'Retail';

export async function renderLibraryScreen() {
    const container = document.getElementById('library-screen');

    // Get collateral for current folder
    const items = await getCollateralByFolder(currentFolder);

    container.innerHTML = `
    <div class="screen-header">
      <h1 class="screen-title">Library</h1>
      <p class="text-secondary">${items.length} item${items.length !== 1 ? 's' : ''}</p>
    </div>
    
    <div class="filter-chips">
      ${FOLDERS.map(folder => `
        <button class="chip ${folder === currentFolder ? 'active' : ''}" data-folder="${folder}">
          ${folder}
        </button>
      `).join('')}
    </div>
    
    ${items.length === 0 ? renderEmptyState() : ''}
    
    <div class="collateral-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: var(--spacing-md); margin-top: var(--spacing-lg);">
      ${items.map(renderCollateralItem).join('')}
    </div>
    
    <button class="btn btn-primary" id="add-collateral-btn" style="width: 100%; margin-top: var(--spacing-lg);">
      + Add Collateral
    </button>
  `;

    // Hide FAB on library screen
    document.getElementById('fab').classList.add('hidden');

    // Attach event listeners
    attachLibraryEventListeners();
}

function renderEmptyState() {
    return `
    <div class="empty-state">
      <div class="empty-icon">📁</div>
      <h3 class="empty-title">No items yet</h3>
      <p class="empty-text">Add collateral to share with leads</p>
    </div>
  `;
}

function renderCollateralItem(item) {
    const icon = getIconForType(item.type);

    return `
    <div class="card" data-collateral-id="${item.id}" style="padding: var(--spacing-md); text-align: center; cursor: pointer;">
      <div style="font-size: 48px; margin-bottom: var(--spacing-sm);">${icon}</div>
      <div style="font-size: var(--font-size-sm); font-weight: 500; margin-bottom: var(--spacing-xs); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
        ${item.name}
      </div>
      <div style="font-size: var(--font-size-xs); color: var(--color-text-tertiary); text-transform: uppercase;">
        ${item.type}
      </div>
      <div style="display: flex; gap: var(--spacing-xs); margin-top: var(--spacing-sm);">
        <button class="btn btn-secondary btn-share" style="flex: 1; font-size: var(--font-size-xs); padding: var(--spacing-xs);">Share</button>
        <button class="btn btn-danger btn-delete" style="flex: 0; font-size: var(--font-size-xs); padding: var(--spacing-xs);">🗑️</button>
      </div>
    </div>
  `;
}

function getIconForType(type) {
    const icons = {
        'pdf': '📄',
        'image': '🖼️',
        'video': '🎥',
        'drive-link': '🔗',
        'whatsapp-template': '💬'
    };
    return icons[type] || '📎';
}

function attachLibraryEventListeners() {
    // Folder chips
    document.querySelectorAll('.filter-chips .chip').forEach(chip => {
        chip.addEventListener('click', (e) => {
            currentFolder = e.target.dataset.folder;
            renderLibraryScreen();
        });
    });

    // Share buttons
    document.querySelectorAll('.btn-share').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const card = e.target.closest('.card');
            const collateralId = parseInt(card.dataset.collateralId);
            const collateral = await getCollateralById(collateralId);
            await shareCollateral(collateral);
        });
    });

    // Delete buttons
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const card = e.target.closest('.card');
            const collateralId = parseInt(card.dataset.collateralId);

            if (confirm('Delete this item?')) {
                await deleteCollateral(collateralId);
                renderLibraryScreen();
            }
        });
    });

    // Add collateral button
    const addBtn = document.getElementById('add-collateral-btn');
    if (addBtn) {
        addBtn.addEventListener('click', () => {
            openAddCollateralDialog();
        });
    }
}

async function openAddCollateralDialog() {
    const name = prompt('Enter collateral name:');
    if (!name) return;

    const type = prompt('Enter type (pdf/image/video/drive-link/whatsapp-template):');
    if (!type) return;

    let url = '';
    let content = '';

    if (type === 'whatsapp-template') {
        content = prompt('Enter template text:');
    } else {
        url = prompt('Enter URL:');
    }

    await createCollateral({
        folder: currentFolder,
        name,
        type,
        url,
        content
    });

    renderLibraryScreen();
}

async function getCollateralById(id) {
    const db = await import('../db/collateral.js');
    return db.getCollateralById(id);
}
