import { getDueReminders, getRemindersByLeadId, markReminderDone, snoozeReminder } from '../db/reminders.js';
import { getLeadById } from '../db/leads.js';
import { formatDateTime, getRelativeTime, isOverdue } from '../utils/date.js';
import { shareViaWhatsApp, openGmail } from '../utils/share.js';

// Priority weights for sorting
const PRIORITY_WEIGHT = {
    'High': 1,
    'Medium': 2,
    'Low': 3
};

export async function renderTodayScreen() {
    const container = document.getElementById('today-screen');

    // Get all due and overdue reminders
    const reminders = await getDueReminders();

    // Fetch associated leads
    const remindersWithLeads = await Promise.all(
        reminders.map(async (reminder) => {
            const lead = await getLeadById(reminder.leadId);
            return { ...reminder, lead };
        })
    );

    // Sort by priority (High -> Medium -> Low)
    remindersWithLeads.sort((a, b) => {
        const priorityDiff = PRIORITY_WEIGHT[a.lead.priority] - PRIORITY_WEIGHT[b.lead.priority];
        if (priorityDiff !== 0) return priorityDiff;
        // If same priority, sort by due date (earliest first)
        return new Date(a.dueDateTime) - new Date(b.dueDateTime);
    });

    // Render
    container.innerHTML = `
    <div class="screen-header">
      <h1 class="screen-title">Today</h1>
      <p class="text-secondary">${remindersWithLeads.length} follow-up${remindersWithLeads.length !== 1 ? 's' : ''}</p>
    </div>
    
    ${remindersWithLeads.length === 0 ? renderEmptyState() : ''}
    
    <div class="reminders-list">
      ${remindersWithLeads.map(renderReminderCard).join('')}
    </div>
  `;

    // Attach event listeners
    attachReminderEventListeners();
}

function renderEmptyState() {
    return `
    <div class="empty-state">
      <div class="empty-icon">✅</div>
      <h3 class="empty-title">All caught up!</h3>
      <p class="empty-text">No follow-ups due right now</p>
    </div>
  `;
}

function renderReminderCard(item) {
    const { lead, ...reminder } = item;
    const overdue = isOverdue(reminder.dueDateTime);
    const relativeTime = getRelativeTime(reminder.dueDateTime);

    return `
    <div class="card mb-md" data-reminder-id="${reminder.id}" data-lead-id="${lead.id}">
      <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: var(--spacing-sm);">
        <div>
          <h3 style="font-size: var(--font-size-lg); margin-bottom: var(--spacing-xs);">${lead.name}</h3>
          <span class="priority-badge priority-${lead.priority.toLowerCase()}">${lead.priority}</span>
        </div>
        <span style="font-size: var(--font-size-sm); color: ${overdue ? 'var(--color-danger)' : 'var(--color-text-secondary)'}; font-weight: 600;">
          ${relativeTime}
        </span>
      </div>
      
      <div style="margin-bottom: var(--spacing-md);">
        <div style="display: flex; align-items: center; gap: var(--spacing-xs); margin-bottom: var(--spacing-xs);">
          <span style="font-size: var(--font-size-sm);">📋 ${reminder.type}</span>
        </div>
        <div style="font-size: var(--font-size-sm); color: var(--color-text-secondary);">
          ${formatDateTime(reminder.dueDateTime)}
        </div>
        ${lead.phone ? `<div style="font-size: var(--font-size-sm); color: var(--color-text-secondary); margin-top: var(--spacing-xs);">📞 ${lead.phone}</div>` : ''}
        ${lead.email ? `<div style="font-size: var(--font-size-sm); color: var(--color-text-secondary); margin-top: var(--spacing-xs);">✉️ ${lead.email}</div>` : ''}
      </div>
      
      <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: var(--spacing-sm);">
        ${lead.phone ? `<button class="btn btn-secondary btn-call" style="font-size: var(--font-size-sm);">📞 Call</button>` : ''}
        ${lead.phone ? `<button class="btn btn-secondary btn-whatsapp" style="font-size: var(--font-size-sm);">💬 WhatsApp</button>` : ''}
        ${lead.email && lead.source === 'Gmail' ? `<button class="btn btn-secondary btn-gmail" style="font-size: var(--font-size-sm);">✉️ Gmail</button>` : ''}
        <button class="btn btn-primary btn-mark-done" style="font-size: var(--font-size-sm);">✓ Done</button>
        <button class="btn btn-secondary btn-snooze" style="font-size: var(--font-size-sm);">⏰ Snooze</button>
      </div>
    </div>
  `;
}

function attachReminderEventListeners() {
    // Mark done buttons
    document.querySelectorAll('.btn-mark-done').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const card = e.target.closest('.card');
            const reminderId = parseInt(card.dataset.reminderId);
            const leadId = parseInt(card.dataset.leadId);

            await markReminderDone(reminderId);

            // Ask if user wants to set next follow-up
            const setNext = confirm('Follow-up marked as done! Set next follow-up?');
            if (setNext) {
                // Open reminder modal with this lead
                window.app.openReminderModal(leadId);
            }

            // Refresh screen
            renderTodayScreen();
        });
    });

    // Snooze buttons
    document.querySelectorAll('.btn-snooze').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const card = e.target.closest('.card');
            const reminderId = parseInt(card.dataset.reminderId);

            await snoozeReminder(reminderId, 60); // Snooze for 1 hour
            renderTodayScreen();
        });
    });

    // Call buttons
    document.querySelectorAll('.btn-call').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const card = e.target.closest('.card');
            const lead = getLeadFromCard(card);
            window.location.href = `tel:${lead.phone}`;
        });
    });

    // WhatsApp buttons
    document.querySelectorAll('.btn-whatsapp').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const card = e.target.closest('.card');
            const lead = getLeadFromCard(card);
            shareViaWhatsApp(lead.phone, `Hi ${lead.name}, `);
        });
    });

    // Gmail buttons
    document.querySelectorAll('.btn-gmail').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const card = e.target.closest('.card');
            const lead = getLeadFromCard(card);
            openGmail(lead.email);
        });
    });
}

function getLeadFromCard(card) {
    // This is a helper to extract lead info from card
    // In a real scenario, we'd fetch from DB, but for quick actions we can parse
    const name = card.querySelector('h3').textContent;
    const phone = card.querySelector('[style*="📞"]')?.textContent.replace('📞 ', '').trim();
    const email = card.querySelector('[style*="✉️"]')?.textContent.replace('✉️ ', '').trim();
    return { name, phone, email };
}
